"""Loopback-only signed forwarding probe on a new, disposable Rust fixture.

Simulates proxy login packets, not a complete Velocity/auth/client integration.
Never reads a production secret or production player records.
"""
import asyncio
import argparse
import datetime as dt
import hashlib
import hmac
import json
import os
from pathlib import Path
import re
import secrets
import shutil
import socket
import struct
import subprocess
import threading
import time
import tomllib
import uuid

ROOT = Path(__file__).resolve().parents[2]
PORT = 25567
RUN = dt.datetime.now(dt.timezone.utc).strftime('%Y%m%d-%H%M%SZ')
WORK = ROOT / 'work/jam-audit/velocity-probes' / RUN
OUT = ROOT / 'outputs/server/jam-proxy' / RUN
SECRET = secrets.token_hex(32)
FORWARDED_UUID = uuid.UUID('b747280e-6a41-40bb-940c-5017b24314f7')
CLAIMED_UUID = uuid.UUID('ad36e568-cd9c-4729-8610-a77a56a5be1b')
NAME = 'JamProxyProbe'
ANSI = re.compile(r'\x1b\[[0-?]*[ -/]*[@-~]')

def vint(value):
    value &= 0xffffffff
    out = bytearray()
    while value > 127:
        out.append((value & 127) | 128)
        value >>= 7
    out.append(value)
    return bytes(out)

def get_vint(data, offset=0):
    n = 0
    for shift in range(0, 35, 7):
        b = data[offset]
        offset += 1
        n |= (b & 127) << shift
        if not b & 128:
            return n, offset
    raise ValueError('oversized VarInt')

def string(s):
    data = s.encode('utf-8')
    return vint(len(data)) + data

def get_string(data, offset=0):
    n, offset = get_vint(data, offset)
    assert n <= 32767 and offset+n <= len(data)
    return data[offset:offset+n].decode('utf-8'), offset+n

async def stream_vint(reader):
    data = bytearray()
    for _ in range(5):
        data.extend(await reader.readexactly(1))
        if not data[-1] & 128:
            return get_vint(data)[0]
    raise ValueError('oversized packet length')

async def read_packet(reader):
    size = await asyncio.wait_for(stream_vint(reader), 8)
    assert 0 < size <= 1024*1024
    data = await asyncio.wait_for(reader.readexactly(size), 8)
    packet_id, offset = get_vint(data)
    return packet_id, data[offset:]

async def send(writer, packet_id, payload):
    data = vint(packet_id) + payload
    writer.write(vint(len(data)) + data)
    await writer.drain()

async def case(label, version=1, signature_ok=True, has_data=True, same_transaction=True):
    reader, writer = await asyncio.open_connection('127.0.0.1', PORT)
    try:
        await send(writer, 0, vint(777)+string('localhost')+struct.pack('>H', PORT)+vint(2))
        await send(writer, 0, string(NAME)+CLAIMED_UUID.bytes)
        packet_id, payload = await read_packet(reader)
        assert packet_id == 4, 'expected login plugin request'
        transaction, offset = get_vint(payload)
        channel, offset = get_string(payload, offset)
        assert channel == 'velocity:player_info'
        max_version, _ = get_vint(payload, offset)
        body = vint(version)+string('127.0.0.1')+FORWARDED_UUID.bytes+string(NAME)+vint(0)
        signature = hmac.digest(SECRET.encode(), body, 'sha256')
        if not signature_ok:
            signature = bytes([signature[0] ^ 1]) + signature[1:]
        response = vint(transaction if same_transaction else transaction ^ 1)
        response += bytes([int(has_data)])
        if has_data:
            response += signature+body
        await send(writer, 2, response)
        packet_id, payload = await read_packet(reader)
        result = {'case': label, 'advertised_max_forwarding_version': max_version,
                  'response_forwarding_version': version, 'login_success': packet_id == 2,
                  'disconnect': packet_id == 0}
        if packet_id == 2:
            actual_uuid = uuid.UUID(bytes=payload[:16])
            actual_name, _ = get_string(payload, 16)
            result['forwarded_uuid_preserved'] = actual_uuid == FORWARDED_UUID and actual_uuid != CLAIMED_UUID
            result['forwarded_name_preserved'] = actual_name == NAME
        else:
            result['disconnect_payload_sha256'] = hashlib.sha256(payload).hexdigest()
        should_accept = label == 'valid_signed_v1'
        result['expected_login_success'] = should_accept
        result['passed'] = ((packet_id == 2 and result.get('forwarded_uuid_preserved') and result.get('forwarded_name_preserved')) if should_accept else packet_id == 0)
        return result
    finally:
        writer.close()
        await writer.wait_closed()

async def main():
    with socket.socket() as s:
        s.bind(('127.0.0.1', PORT))  # Fail if this test port is occupied.
    WORK.mkdir(parents=True, exist_ok=False)
    OUT.mkdir(parents=True, exist_ok=False)
    binary = SOURCE_BINARY
    expected = EXPECTED_SHA256
    actual = hashlib.file_digest(binary.open('rb'), 'sha256').hexdigest()
    assert actual == expected
    fixture_binary = WORK/('pumpkin.exe' if os.name == 'nt' else 'pumpkin')
    shutil.copy2(binary, fixture_binary)
    profile = '''default_level_name = "proxy-fixture"
seed = "horizon-rust-first-slice"
default_gamemode = "Survival"
spawn_protection = 0
allow_nether = false
allow_end = false
allow_chat_reports = false
white_list = false
[networking.java]
enabled = true
address = "127.0.0.1:25567"
encryption = false
online_mode = false
max_players = 2
view_distance = 2
simulation_distance = 2
[networking.java.compression]
enabled = false
[networking.bedrock]
enabled = false
[networking.query]
enabled = false
[networking.management]
enabled = false
[networking.lan_broadcast]
enabled = false
[networking.proxy]
enabled = true
[networking.proxy.velocity]
enabled = true
secret = "FIXTURE_SECRET"
[telemetry]
enabled = false
public = false
[plugins]
enabled = false
'''.replace('FIXTURE_SECRET', SECRET)
    (WORK/'pumpkin.toml').write_text(profile, encoding='utf-8')
    log = (OUT/'server.log').open('w', encoding='utf-8')
    lines = []
    process = subprocess.Popen([str(fixture_binary)], cwd=WORK,
        stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        text=True, encoding='utf-8', errors='replace',
        env=dict(os.environ, RUST_LOG='info', NO_COLOR='1'), creationflags=subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0)
    def consume():
        for line in process.stdout:
            clean = ANSI.sub('', line).replace(SECRET, '<fixture-secret>')
            lines.append(clean)
            log.write(clean)
            log.flush()
    thread = threading.Thread(target=consume, daemon=True)
    thread.start()
    report = {'engine_commit': 'ff873cbbb8cc8fe591fb09aaf7d70b30517a57d0', 'binary_sha256': actual,
              'protocol':777, 'port':PORT, 'fixture_uses_production_data':False,
              'scope':'Synthetic v1 signed login forwarding only; not actual Velocity, authentication, profile-key validation, play or migration acceptance.',
              'cases':[]}
    try:
        deadline = time.monotonic()+90
        while not any('Server is now running.' in l for l in lines):
            if process.poll() is not None:
                raise RuntimeError('fixture exited during startup')
            if time.monotonic() > deadline:
                raise TimeoutError('fixture startup timeout')
            await asyncio.sleep(.25)
        effective = tomllib.loads((WORK/'pumpkin.toml').read_text(encoding='utf-8'))
        assert effective['networking']['proxy']['velocity']['enabled'] is True
        assert effective['networking']['proxy']['velocity']['secret'] == SECRET
        assert effective['networking']['java']['address'] == '127.0.0.1:25567'
        assert effective['networking']['java']['online_mode'] is False
        assert effective['plugins']['enabled'] is False
        assert effective['telemetry']['enabled'] is False
        print(json.dumps({'event':'fixture_started','pid':process.pid,'port':PORT}), flush=True)
        scenarios = [('valid_signed_v1', {}), ('invalid_hmac', {'signature_ok':False}),
            ('no_forwarding_data', {'has_data':False}), ('unsupported_version_5', {'version':5}),
            ('wrong_transaction_id', {'same_transaction':False}), ('wrapped_version_257', {'version':257})]
        for label, kwargs in scenarios:
            result = await case(label, **kwargs)
            report['cases'].append(result)
            print(json.dumps(result), flush=True)
    finally:
        if process.poll() is None:
            process.stdin.write('stop\n')
            process.stdin.flush()
            process.stdin.close()
            try:
                await asyncio.to_thread(process.wait, timeout=30)
            except subprocess.TimeoutExpired:
                process.kill()
                await asyncio.to_thread(process.wait, timeout=5)
                report['forced_fixture_shutdown'] = True
        thread.join(timeout=3)
        log.close()
        report['exit_code'] = process.returncode
        report['clean_shutdown'] = any('The server has stopped' in l for l in lines) and process.returncode == 0
        report['all_cases_passed'] = len(report['cases']) == 6 and all(r['passed'] for r in report['cases'])
        (OUT/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n', encoding='utf-8')
        print(json.dumps({'event':'finished','output':str(OUT),'clean_shutdown':report['clean_shutdown'],'all_cases_passed':report['all_cases_passed']}), flush=True)

    return report['all_cases_passed'] and report['clean_shutdown']

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--binary', type=Path, required=True)
    parser.add_argument('--sha256', required=True)
    args = parser.parse_args()
    SOURCE_BINARY = args.binary.resolve()
    EXPECTED_SHA256 = args.sha256.lower()
    assert re.fullmatch(r'[0-9a-f]{64}', EXPECTED_SHA256)
    print(json.dumps({'event':'probe_prepared','production_data':False,'port':PORT}), flush=True)
    raise SystemExit(0 if asyncio.run(main()) else 1)

"""Проверить либо применить Jam-патч к отдельной чистой копии Pumpkin."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess

SERVER=Path(__file__).resolve().parents[1]

def git(engine,*args):
    return subprocess.check_output(['git','-C',str(engine),*args],text=True,encoding='utf-8').strip()

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--engine',type=Path,required=True)
    parser.add_argument('--apply',action='store_true')
    parser.add_argument('--report',type=Path)
    args=parser.parse_args()
    engine=args.engine.resolve()
    protected=(SERVER/'engine').resolve()
    series=json.loads((SERVER/'patches/series.json').read_text(encoding='utf-8'))
    assert git(engine,'rev-parse','HEAD')==series['baseline_commit'], 'Неверный исходный commit'
    assert not git(engine,'status','--porcelain'), 'Требуется чистая отдельная копия'
    assert not(args.apply and (engine==protected or engine.is_relative_to(protected))), 'Исходный engine защищён от применения патча'
    for entry in series['patches']:
        patch=SERVER/'patches'/entry['file']
        assert hashlib.sha256(patch.read_bytes()).hexdigest()==entry['sha256'], 'Изменена контрольная сумма патча'
        git(engine,'apply','--check',str(patch))
    if args.apply:
        for entry in series['patches']:
            git(engine,'apply',str(SERVER/'patches'/entry['file']))
        changed=set(git(engine,'diff','--name-only').splitlines())
        expected={p for entry in series['patches'] for p in entry['touched_paths']}
        assert changed==expected, 'Неожиданный набор изменённых исходников'
    report={'baseline_commit':series['baseline_commit'],'patches':series['patches'],
            'applied':args.apply,'clean_apply_check_passed':True,
            'native_build_or_tests_run':False,'fixed_runtime_confirmed':False}
    if args.report:
        args.report.parent.mkdir(parents=True,exist_ok=True)
        args.report.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(report,ensure_ascii=False))

if __name__=='__main__':
    main()

#!/usr/bin/env python3
"""Сборка на Linux; --check-only проверяет checkout без запуска компилятора."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
from datetime import datetime, timezone

SERVER = Path(__file__).resolve().parents[1]
PROJECT = Path(os.environ.get("HORIZON_PROJECT_ROOT",
                             SERVER if (SERVER / ".git").exists() else SERVER.parent)).resolve()
LOCK = json.loads((SERVER / "upstream.lock.json").read_text(encoding="utf-8"))
ENGINE = SERVER / "engine"


def run(args, *, cwd=SERVER, env=None, log=None):
    if log is None:
        return subprocess.check_output(args, cwd=cwd, env=env, text=True).strip()
    with log.open("w", encoding="utf-8") as output:
        process = subprocess.Popen(args, cwd=cwd, env=env, stdout=subprocess.PIPE,
                                   stderr=subprocess.STDOUT, text=True, errors="replace")
        assert process.stdout is not None
        for line in process.stdout:
            output.write(line)
            output.flush()
            print(line, end="", flush=True)
        if process.wait() != 0:
            raise RuntimeError(f"Команда завершилась с ошибкой; журнал: {log}")


def sha256(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def source_sha256(path):
    # Compare canonical Git text bytes across LF and CRLF checkouts.
    return hashlib.sha256(path.read_bytes().replace(b"\r\n", b"\n")).hexdigest()


def check_upstream():
    if run(["git", "rev-parse", "HEAD"], cwd=ENGINE) != LOCK["commit"]:
        raise RuntimeError("Engine HEAD не совпадает с upstream.lock.json")
    if run(["git", "diff", "HEAD", "--"], cwd=ENGINE):
        raise RuntimeError("В engine есть изменения отслеживаемых файлов")
    expected = {"Cargo.lock": LOCK["engine_cargo_lock_sha256"], **LOCK["licenses"]}
    for relative, digest in expected.items():
        if source_sha256(ENGINE / relative) != digest:
            raise RuntimeError(f"Контрольная сумма не совпадает: {relative}")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check-only", action="store_true")
    parser.add_argument("--jobs", type=int, choices=range(1, 65), default=2)
    args = parser.parse_args()
    check_upstream()
    if args.check_only:
        print("PASS: закреплённый commit, Cargo.lock, LICENSE и чистота tracked files")
        return
    if not sys.platform.startswith("linux"):
        raise RuntimeError("Для сборки этим сценарием требуется Linux")
    env = dict(os.environ)
    env["RUSTUP_TOOLCHAIN"] = LOCK["toolchain"]["rust"]
    env["CARGO_HOME"] = str(PROJECT / "work/toolchains/cargo-linux")
    work = Path(env.get("HORIZON_BUILD_ROOT", PROJECT / "work/build/linux")).resolve()
    out = Path(env.get("HORIZON_OUTPUT_ROOT", PROJECT / "outputs/server/linux")).resolve()
    work.mkdir(parents=True, exist_ok=True)
    env["TMPDIR"] = str(work / "temp")
    Path(env["TMPDIR"]).mkdir(exist_ok=True)
    cargo = shutil.which("cargo")
    if cargo is None:
        raise RuntimeError("Cargo отсутствует; сначала установите закреплённый Rust из lock")
    plugin = SERVER / "plugins/horizon-base/Cargo.toml"
    env["CARGO_TARGET_DIR"] = str(work / "plugin")
    commands = [
        ([cargo, "fmt", "--manifest-path", str(plugin), "--check"], "format.log"),
        ([cargo, "test", "--locked", "-j", str(args.jobs), "--manifest-path", str(plugin)], "tests.log"),
        ([sys.executable, str(SERVER / "tests/check_profile.py")], "profile.log"),
        ([cargo, "build", "--release", "--locked", "-j", str(args.jobs), "--target",
          LOCK["toolchain"]["plugin_target"], "--manifest-path", str(plugin)], "wasm.log"),
    ]
    for command, log_name in commands:
        run(command, env=env, log=work / log_name)
    env["CARGO_TARGET_DIR"] = str(work / "engine")
    run([cargo, "build", "--release", "--locked", "-j", str(args.jobs), "-p", "pumpkin"],
        cwd=ENGINE, env=env, log=work / "engine.log")
    copies = {
        work / "engine/release/pumpkin": "bin/pumpkin",
        work / "plugin/wasm32-wasip2/release/horizon_base.wasm": "plugins/horizon-base.wasm",
        SERVER / "config/pumpkin.toml": "config/pumpkin.toml",
        SERVER / "config/horizon-base.toml": "config/horizon-base.toml",
        SERVER / "upstream.lock.json": "upstream.lock.json",
        SERVER / "README.md": "README.md",
        SERVER / "THIRD-PARTY-NOTICES.md": "licenses/THIRD-PARTY-NOTICES.md",
        ENGINE / "LICENSE": "licenses/Pumpkin-GPL-3.0.txt",
        ENGINE / "crates/pumpkin-plugin-api/LICENSE-MIT": "licenses/Plugin-API-MIT.txt",
        ENGINE / "crates/pumpkin-plugin-api/LICENSE-APACHE": "licenses/Plugin-API-Apache-2.0.txt",
    }
    artifacts = []
    for source, relative in copies.items():
        destination = out / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, destination)
        artifacts.append({"path": relative, "sha256": sha256(destination)})
    report = {"engine_commit": LOCK["commit"], "rust_toolchain": env["RUSTUP_TOOLCHAIN"],
              "built_at_utc": datetime.now(timezone.utc).isoformat(), "artifacts": artifacts,
              "gameplay_acceptance": "not-run"}
    (out / "build-report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(f"Сборочные артефакты: {out}; игровая приёмка выполняется отдельно")


if __name__ == "__main__":
    try:
        main()
    except (OSError, RuntimeError, subprocess.CalledProcessError) as error:
        print(f"ERROR: {error}", file=sys.stderr)
        raise SystemExit(1)

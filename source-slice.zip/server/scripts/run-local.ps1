#requires -Version 7.0
param([ValidateSet('online', 'offline-fixture')][string] $Profile = 'online')
. (Join-Path $PSScriptRoot 'common.ps1')
$binary = Join-Path $OutputRoot 'bin/pumpkin.exe'
$wasm = Join-Path $OutputRoot 'plugins/horizon-base.wasm'
if (-not (Test-Path -LiteralPath $binary) -or -not (Test-Path -LiteralPath $wasm)) { throw 'Run server/scripts/build.ps1 first.' }
$runtime = Join-Path $WorkRoot "runtime/$Profile"
$data = Join-Path $runtime 'plugins/data/horizon-base'
New-Item -ItemType Directory -Force -Path $data | Out-Null
$config = Get-Content -Raw -LiteralPath (Join-Path $ServerRoot 'config/pumpkin.toml')
if ($Profile -eq 'offline-fixture') {
    $config = $config.Replace('online_mode = true', 'online_mode = false').Replace('encryption = true', 'encryption = false').Replace('127.0.0.1:25565', '127.0.0.1:25566').Replace('horizon-test', 'horizon-offline-fixture')
}
# Always restore the isolated network policy; user rules live in the plugin's own data file.
$config | Set-Content -LiteralPath (Join-Path $runtime 'pumpkin.toml') -Encoding utf8
Copy-Item -LiteralPath $wasm -Destination (Join-Path $runtime 'plugins/horizon-base.wasm') -Force
$pluginConfig = Join-Path $data 'horizon-base.toml'
if (-not (Test-Path -LiteralPath $pluginConfig)) {
    Copy-Item -LiteralPath (Join-Path $ServerRoot 'config/horizon-base.toml') -Destination $pluginConfig
}
Write-Output "Local $Profile profile: $runtime. Stop with the console command: stop"
Push-Location $runtime
try { & $binary; if ($LASTEXITCODE -ne 0) { throw "Pumpkin exited with code $LASTEXITCODE" } }
finally { Pop-Location }

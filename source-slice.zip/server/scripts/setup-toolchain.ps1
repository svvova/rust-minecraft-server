#requires -Version 7.0
# Installs pinned tools under work/. No system installation or persistent PATH changes.
. (Join-Path $PSScriptRoot 'common.ps1')
New-Item -ItemType Directory -Force -Path $ToolRoot | Out-Null

function Get-PinnedArchive([string] $Url, [string] $Destination, [string] $Sha256) {
    if (-not (Test-Path -LiteralPath $Destination)) {
        & curl.exe --fail --location --retry 3 --output $Destination $Url
        if ($LASTEXITCODE -ne 0) { throw "Download failed: $Url" }
    }
    Assert-Hash $Destination $Sha256
}

$rustupDownload = Join-Path $ToolRoot 'rustup-init.exe'
Get-PinnedArchive $UpstreamLock.toolchain.rustup_archive_url $rustupDownload $UpstreamLock.toolchain.rustup_sha256
$rustup = Join-Path $ToolRoot 'rustup.exe'
Copy-Item -LiteralPath $rustupDownload -Destination $rustup -Force
# Direct rustup and real toolchain binaries avoid Windows executable hardlink restrictions.
& $rustup set auto-self-update disable
if ($LASTEXITCODE -ne 0) { throw 'Cannot configure local rustup.' }
& $rustup toolchain install "$($UpstreamLock.toolchain.rust)-$($UpstreamLock.toolchain.host)" --profile minimal --component rustfmt --target $UpstreamLock.toolchain.plugin_target
if ($LASTEXITCODE -ne 0) { throw 'Rust toolchain installation failed.' }

$llvmArchive = Join-Path $ToolRoot "llvm-mingw-$($UpstreamLock.toolchain.llvm_mingw).zip"
Get-PinnedArchive $UpstreamLock.toolchain.llvm_archive_url $llvmArchive $UpstreamLock.toolchain.llvm_archive_sha256
if (-not (Test-Path -LiteralPath (Join-Path $LlvmBin 'clang.exe'))) {
    & tar.exe -xf $llvmArchive -C $ToolRoot
    if ($LASTEXITCODE -ne 0) { throw 'LLVM-MinGW extraction failed.' }
}
& (Join-Path $RustBin 'rustc.exe') --version
& (Join-Path $LlvmBin 'clang.exe') --version

#requires -Version 7.0
$ErrorActionPreference = 'Stop'
$ServerRoot = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
if ($env:HORIZON_PROJECT_ROOT) {
    $ProjectRoot = [IO.Path]::GetFullPath($env:HORIZON_PROJECT_ROOT)
} elseif (Test-Path -LiteralPath (Join-Path $ServerRoot '.git')) {
    $ProjectRoot = $ServerRoot
} else {
    $ProjectRoot = [IO.Directory]::GetParent($ServerRoot).FullName
}
$WorkRoot = Join-Path $ProjectRoot 'work'
$OutputRoot = Join-Path $ProjectRoot 'outputs/server'
$UpstreamLock = Get-Content -Raw -LiteralPath (Join-Path $ServerRoot 'upstream.lock.json') | ConvertFrom-Json
$ToolRoot = Join-Path $WorkRoot 'toolchains'
$env:RUSTUP_HOME = Join-Path $ToolRoot 'rustup'
$env:CARGO_HOME = Join-Path $ToolRoot 'cargo'
$env:RUSTUP_TOOLCHAIN = "$($UpstreamLock.toolchain.rust)-$($UpstreamLock.toolchain.host)"
$RustBin = Join-Path $env:RUSTUP_HOME "toolchains/$($UpstreamLock.toolchain.rust)-$($UpstreamLock.toolchain.host)/bin"
$LlvmBin = Join-Path $ToolRoot "llvm-mingw-$($UpstreamLock.toolchain.llvm_mingw)/bin"
$Cargo = Join-Path $RustBin 'cargo.exe'
$env:PATH = "$RustBin;$LlvmBin;$env:PATH"
$env:CARGO_TARGET_X86_64_PC_WINDOWS_GNULLVM_LINKER = Join-Path $LlvmBin 'clang.exe'
$env:CC = Join-Path $LlvmBin 'clang.exe'
$env:CXX = Join-Path $LlvmBin 'clang++.exe'
$env:AR = Join-Path $LlvmBin 'llvm-ar.exe'
# Rust/LLVM temporary files and build-script caches remain in the workspace.
$env:TEMP = Join-Path $WorkRoot 'temp'
$env:TMP = $env:TEMP
New-Item -ItemType Directory -Force -Path $env:TEMP | Out-Null

function Assert-Hash([string] $Path, [string] $Expected, [switch] $TextSource) {
    if ($TextSource) {
        # Git's Windows checkout may use CRLF; the lock records canonical LF blobs.
        $utf8 = [Text.UTF8Encoding]::new($false, $true)
        $text = $utf8.GetString([IO.File]::ReadAllBytes($Path)).Replace("`r`n", "`n")
        $actual = [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($utf8.GetBytes($text)))
    } else {
        $actual = (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash
    }
    if ($actual -ne $Expected) { throw "SHA-256 mismatch: $Path" }
}

function Assert-Upstream {
    $engine = Join-Path $ServerRoot 'engine'
    $head = & git -C $engine rev-parse HEAD
    if ($LASTEXITCODE -ne 0 -or $head -ne $UpstreamLock.commit) {
        throw "Engine HEAD must match upstream.lock.json ($($UpstreamLock.commit)); refs are never updated automatically."
    }
    & git -C $engine diff --quiet HEAD --
    if ($LASTEXITCODE -ne 0) { throw 'Engine contains tracked changes; inspect them before building.' }
    Assert-Hash (Join-Path $engine 'Cargo.lock') $UpstreamLock.engine_cargo_lock_sha256 -TextSource
    foreach ($entry in $UpstreamLock.licenses.PSObject.Properties) {
        Assert-Hash (Join-Path $engine $entry.Name) $entry.Value -TextSource
    }
}

function Invoke-Cargo([string[]] $CargoArguments, [string] $LogName) {
    $logDir = Join-Path $WorkRoot 'build'
    New-Item -ItemType Directory -Force -Path $logDir | Out-Null
    & $Cargo @CargoArguments 2>&1 | Tee-Object -FilePath (Join-Path $logDir $LogName)
    if ($LASTEXITCODE -ne 0) { throw "Cargo failed; see work/build/$LogName" }
}

#requires -Version 7.0
param([ValidateRange(1, 64)][int] $Jobs = 2, [switch] $PluginOnly)
. (Join-Path $PSScriptRoot 'common.ps1')
if (-not (Test-Path -LiteralPath $Cargo) -or -not (Test-Path -LiteralPath (Join-Path $LlvmBin 'clang.exe'))) {
    & (Join-Path $PSScriptRoot 'setup-toolchain.ps1')
    if (-not $?) { throw 'Toolchain setup failed.' }
}
Assert-Upstream
if ($PluginOnly) { $OutputRoot = Join-Path $OutputRoot 'plugin-only' }
$pluginManifest = Join-Path $ServerRoot 'plugins/horizon-base/Cargo.toml'
$env:CARGO_TARGET_DIR = Join-Path $WorkRoot 'build/plugin'
Invoke-Cargo @('fmt', '--manifest-path', $pluginManifest, '--check') 'plugin-format.log'
Invoke-Cargo @('test', '--locked', '-j', "$Jobs", '--manifest-path', $pluginManifest) 'plugin-tests.log'
Invoke-Cargo @('build', '--release', '--locked', '-j', "$Jobs", '--target', $UpstreamLock.toolchain.plugin_target, '--manifest-path', $pluginManifest) 'plugin-build.log'

if (-not $PluginOnly) {
    $env:CARGO_TARGET_DIR = Join-Path $WorkRoot 'build/engine'
    Push-Location (Join-Path $ServerRoot 'engine')
    try { Invoke-Cargo @('build', '--release', '--locked', '-j', "$Jobs", '-p', 'pumpkin') 'engine-build.log' }
    finally { Pop-Location }
}

New-Item -ItemType Directory -Force -Path (Join-Path $OutputRoot 'bin'), (Join-Path $OutputRoot 'plugins'), (Join-Path $OutputRoot 'config'), (Join-Path $OutputRoot 'licenses') | Out-Null
Copy-Item -LiteralPath (Join-Path $WorkRoot 'build/plugin/wasm32-wasip2/release/horizon_base.wasm') -Destination (Join-Path $OutputRoot 'plugins/horizon-base.wasm') -Force
if (-not $PluginOnly) {
    Copy-Item -LiteralPath (Join-Path $WorkRoot 'build/engine/release/pumpkin.exe') -Destination (Join-Path $OutputRoot 'bin/pumpkin.exe') -Force
    # GNU LLVM unwinding may require this DLL on machines without the build tools.
    $unwind = Join-Path $LlvmBin 'libunwind.dll'
    if (Test-Path -LiteralPath $unwind) { Copy-Item -LiteralPath $unwind -Destination (Join-Path $OutputRoot 'bin/libunwind.dll') -Force }
}
Copy-Item -LiteralPath (Join-Path $ServerRoot 'config/pumpkin.toml'), (Join-Path $ServerRoot 'config/horizon-base.toml') -Destination (Join-Path $OutputRoot 'config') -Force
Copy-Item -LiteralPath (Join-Path $ServerRoot 'upstream.lock.json'), (Join-Path $ServerRoot 'README.md') -Destination $OutputRoot -Force
Copy-Item -LiteralPath (Join-Path $ServerRoot 'engine/LICENSE') -Destination (Join-Path $OutputRoot 'licenses/Pumpkin-GPL-3.0.txt') -Force
Copy-Item -LiteralPath (Join-Path $ServerRoot 'engine/crates/pumpkin-plugin-api/LICENSE-MIT') -Destination (Join-Path $OutputRoot 'licenses/Plugin-API-MIT.txt') -Force
Copy-Item -LiteralPath (Join-Path $ServerRoot 'engine/crates/pumpkin-plugin-api/LICENSE-APACHE') -Destination (Join-Path $OutputRoot 'licenses/Plugin-API-Apache-2.0.txt') -Force
Copy-Item -LiteralPath (Join-Path $ServerRoot 'THIRD-PARTY-NOTICES.md') -Destination (Join-Path $OutputRoot 'licenses') -Force
Copy-Item -LiteralPath (Join-Path $ToolRoot "llvm-mingw-$($UpstreamLock.toolchain.llvm_mingw)/LICENSE.TXT") -Destination (Join-Path $OutputRoot 'licenses/LLVM-MinGW-LICENSE.txt') -Force
$artifacts = Get-ChildItem -LiteralPath (Join-Path $OutputRoot 'bin'), (Join-Path $OutputRoot 'plugins') -File | ForEach-Object {
    [ordered]@{ path = $_.FullName.Substring($OutputRoot.Length + 1); sha256 = (Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash.ToLowerInvariant() }
}
[ordered]@{
    built_at_utc = [DateTime]::UtcNow.ToString('o')
    engine_commit = $UpstreamLock.commit
    rust = (& (Join-Path $RustBin 'rustc.exe') --version)
    plugin_only = [bool]$PluginOnly
    artifacts = @($artifacts)
} | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $OutputRoot 'build-report.json') -Encoding utf8
Write-Output "Build artifacts: $OutputRoot"

use crate::config::Config;

pub const BYPASS_PERMISSION: &str = "horizon.base.bypass";

/// Inclusive X/Z square. Widen before subtraction so all i32 coordinates are safe.
pub fn should_cancel(config: &Config, world: &str, x: i32, z: i32, has_bypass: bool) -> bool {
    config.enabled
        && !has_bypass
        && config.worlds.iter().any(|rule| {
            rule.enabled
                && rule.world == world
                && (i64::from(x) - i64::from(rule.center_x)).abs() <= i64::from(rule.radius)
                && (i64::from(z) - i64::from(rule.center_z)).abs() <= i64::from(rule.radius)
        })
}

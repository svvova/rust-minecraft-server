pub mod config;
pub mod rules;

#[cfg(target_arch = "wasm32")]
mod runtime {
    use crate::{
        config::Config,
        rules::{BYPASS_PERMISSION, should_cancel},
    };
    use pumpkin_plugin_api::{
        Context, Plugin, PluginMetadata, Server,
        command::{CommandError, CommandNode, CommandSender, ConsumedArgs},
        commands::{Command, CommandHandler},
        events::{BlockBreakEvent, BlockPlaceEvent, EventData, EventHandler, EventPriority},
        permission::{Permission, PermissionDefault},
        permissions::{FS_READ_DATA, FS_WRITE_DATA},
        text::TextComponent,
    };
    use std::{
        path::Path,
        sync::{
            Arc,
            atomic::{AtomicBool, Ordering},
        },
    };

    const STATUS_PERMISSION: &str = "horizon-base:status";
    const UPSTREAM: &str = "ff873cbbb8cc8fe591fb09aaf7d70b30517a57d0";

    pub struct HorizonBase {
        loaded: Arc<AtomicBool>,
    }

    impl Plugin for HorizonBase {
        fn new() -> Self {
            Self {
                loaded: Arc::new(AtomicBool::new(false)),
            }
        }

        fn metadata(&self) -> PluginMetadata {
            PluginMetadata {
                name: "horizon-base".into(),
                version: env!("CARGO_PKG_VERSION").into(),
                authors: vec![],
                description: "Horizon local Rust/WASM server slice".into(),
                dependencies: vec![],
                permissions: vec![FS_READ_DATA.into(), FS_WRITE_DATA.into()],
            }
        }

        fn on_load(&self, context: Context) -> Result<(), String> {
            self.loaded.store(false, Ordering::Release);
            let folder = context.get_data_folder();
            let config = Arc::new(Config::load_or_create(
                &Path::new(&folder).join("horizon-base.toml"),
            )?);
            context.register_permission(&Permission {
                node: STATUS_PERMISSION.into(),
                description: "Read Horizon server/plugin status".into(),
                default: PermissionDefault::Allow,
                children: vec![],
            })?;
            // v0.1 registration requires the plugin-name: namespace. Keep the
            // specified bypass node exact; unknown nodes deny unless explicitly attached.
            context.register_event_handler::<BlockBreakEvent, _>(
                Protection(config.clone()),
                EventPriority::Highest,
                true,
            )?;
            context.register_event_handler::<BlockPlaceEvent, _>(
                Protection(config.clone()),
                EventPriority::Highest,
                true,
            )?;
            let command = Command::new(&["horizon".into()], "Horizon server status").then(
                CommandNode::literal("status").execute(Status {
                    config,
                    loaded: self.loaded.clone(),
                }),
            );
            context.register_command(command, STATUS_PERMISSION);
            self.loaded.store(true, Ordering::Release);
            Ok(())
        }

        fn on_unload(&self, _context: Context) -> Result<(), String> {
            self.loaded.store(false, Ordering::Release);
            Ok(())
        }
    }

    struct Protection(Arc<Config>);

    impl EventHandler<BlockBreakEvent> for Protection {
        fn handle(
            &self,
            _server: Server,
            mut event: EventData<BlockBreakEvent>,
        ) -> EventData<BlockBreakEvent> {
            if let Some(player) = event.player.as_ref() {
                event.cancelled |= should_cancel(
                    &self.0,
                    &player.get_world().get_name(),
                    event.block_pos.x,
                    event.block_pos.z,
                    player.has_permission(BYPASS_PERMISSION),
                );
            }
            event
        }
    }

    impl EventHandler<BlockPlaceEvent> for Protection {
        fn handle(
            &self,
            _server: Server,
            mut event: EventData<BlockPlaceEvent>,
        ) -> EventData<BlockPlaceEvent> {
            event.cancelled |= should_cancel(
                &self.0,
                &event.player.get_world().get_name(),
                event.block_pos.x,
                event.block_pos.z,
                event.player.has_permission(BYPASS_PERMISSION),
            );
            event
        }
    }

    struct Status {
        config: Arc<Config>,
        loaded: Arc<AtomicBool>,
    }

    impl CommandHandler for Status {
        fn handle(
            &self,
            sender: CommandSender,
            _server: Server,
            _args: ConsumedArgs,
        ) -> Result<i32, CommandError> {
            if !self.loaded.load(Ordering::Acquire) {
                return Err(CommandError::CommandFailed(TextComponent::text(
                    "horizon-base is not loaded",
                )));
            }
            let state = if self.config.active_worlds() == 0 {
                "disabled"
            } else {
                "enabled"
            };
            sender.send_message(&TextComponent::text(&format!(
                "Horizon Rust server | Pumpkin {UPSTREAM} | horizon-base {} | Java 26.3 / protocol 777 | WASM API 0.1 | protection {state} ({} worlds)",
                env!("CARGO_PKG_VERSION"), self.config.active_worlds(),
            )));
            Ok(1)
        }
    }
}

#[cfg(target_arch = "wasm32")]
pumpkin_plugin_api::register_plugin!(runtime::HorizonBase);

use serde::Deserialize;
use std::{collections::HashSet, io::Read, path::Path};

pub const MAX_CONFIG_BYTES: u64 = 65_536;
pub const MAX_RADIUS: u16 = 1024;
const MAX_WORLDS: usize = 128;
pub const EXAMPLE_CONFIG: &str = include_str!("../../../config/horizon-base.toml");

#[derive(Debug, Default, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Config {
    #[serde(default)]
    pub enabled: bool,
    #[serde(default)]
    pub worlds: Vec<WorldRule>,
}

#[derive(Debug, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct WorldRule {
    pub world: String,
    pub enabled: bool,
    pub center_x: i32,
    pub center_z: i32,
    pub radius: u16,
}

impl Config {
    pub fn parse(input: &str) -> Result<Self, String> {
        if input.len() as u64 > MAX_CONFIG_BYTES {
            return Err("horizon-base config exceeds 64 KiB".into());
        }
        let config: Self =
            toml::from_str(input).map_err(|error| format!("invalid horizon-base TOML: {error}"))?;
        if config.worlds.len() > MAX_WORLDS {
            return Err("horizon-base config exceeds 128 world rules".into());
        }
        let mut names = HashSet::new();
        for rule in &config.worlds {
            if rule.world.trim().is_empty() || rule.world.len() > 255 {
                return Err("world must contain 1–255 bytes and cannot be blank".into());
            }
            if !names.insert(rule.world.as_str()) {
                return Err(format!("duplicate world rule: {}", rule.world));
            }
            if rule.radius > MAX_RADIUS {
                return Err(format!("radius for {} must be 0–1024", rule.world));
            }
        }
        Ok(config)
    }

    pub fn from_reader(reader: impl Read) -> Result<Self, String> {
        let mut input = String::new();
        reader
            .take(MAX_CONFIG_BYTES + 1)
            .read_to_string(&mut input)
            .map_err(|error| format!("cannot read horizon-base config: {error}"))?;
        Self::parse(&input)
    }

    pub fn load_or_create(path: &Path) -> Result<Self, String> {
        use std::fs::{File, OpenOptions};
        use std::io::{ErrorKind, Write};

        match OpenOptions::new().write(true).create_new(true).open(path) {
            Ok(mut file) => file
                .write_all(EXAMPLE_CONFIG.as_bytes())
                .map_err(|error| format!("cannot create horizon-base config: {error}"))?,
            Err(error) if error.kind() == ErrorKind::AlreadyExists => {}
            Err(error) => return Err(format!("cannot create horizon-base config: {error}")),
        }
        let file = File::open(path)
            .map_err(|error| format!("cannot open horizon-base config: {error}"))?;
        Self::from_reader(file)
    }

    pub fn active_worlds(&self) -> usize {
        if self.enabled {
            self.worlds.iter().filter(|rule| rule.enabled).count()
        } else {
            0
        }
    }
}

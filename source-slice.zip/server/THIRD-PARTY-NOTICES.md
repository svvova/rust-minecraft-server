**Состав и атрибуция**

- Pumpkin, https://github.com/Pumpkin-MC/Pumpkin, commit `ff873cbbb8cc8fe591fb09aaf7d70b30517a57d0`: GPL-3.0 по upstream `LICENSE`. Полный checkout, copyright notices и исходные лицензии сохранены в `server/engine/`. Код сервера не переименован в компонент Horizon с другой лицензией.
- Pumpkin plugin API / WIT: MIT OR Apache-2.0 по собственным LICENSE-файлам в соответствующих crates. `horizon-base` — отдельный собственный модуль, использующий этот API. Код движка не скопирован в модуль.
- Rust и LLVM-MinGW — сборочные инструменты в `work/toolchains/` со своими upstream notices. При включении runtime DLL в `outputs/server/bin/` применяется лицензия LLVM с исключением для runtime; её копия добавляется рядом с итоговыми notices.
- Cargo-зависимости закреплены отдельными Cargo.lock; их условия сохраняются у upstream. Этот файл не заменяет лицензии зависимостей.
- Vanilla datapack подготавливается неизменённым build.rs Pumpkin из официального Minecraft server archive; `.jar` не исполняется, Java bridge отсутствует. Minecraft остаётся продуктом Mojang/Microsoft со своими условиями.
- Purpur не является зависимостью или включённым кодом этого среза.

Локальная сборка ничего не публикует и не предоставляет полномочий от имени сопровождающих upstream.

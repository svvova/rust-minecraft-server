use horizon_base::{
    config::{Config, EXAMPLE_CONFIG, MAX_CONFIG_BYTES},
    rules::should_cancel,
};

fn config_at(x: i32, z: i32, radius: u16) -> Config {
    Config::parse(&format!("enabled = true\n[[worlds]]\nworld = 'test'\nenabled = true\ncenter_x = {x}\ncenter_z = {z}\nradius = {radius}")).unwrap()
}

#[test]
fn inclusive_square_edges_and_corners() {
    let config = config_at(100, -100, 16);
    for (x, z) in [(84, -116), (116, -84), (100, -100), (84, -100), (100, -84)] {
        assert!(should_cancel(&config, "test", x, z, false));
    }
    for (x, z) in [(83, -100), (117, -100), (100, -117), (100, -83)] {
        assert!(!should_cancel(&config, "test", x, z, false));
    }
}

#[test]
fn zero_radius_is_one_column_and_max_radius_is_allowed() {
    let zero = config_at(0, 0, 0);
    assert!(should_cancel(&zero, "test", 0, 0, false));
    assert!(!should_cancel(&zero, "test", 1, 0, false));
    let max = config_at(0, 0, 1024);
    assert!(should_cancel(&max, "test", -1024, 1024, false));
    assert!(!should_cancel(&max, "test", -1025, 1024, false));
}

#[test]
fn permission_world_and_enable_flags_gate_protection() {
    let mut config = config_at(0, 0, 16);
    assert!(!should_cancel(&config, "test", 0, 0, true));
    assert!(!should_cancel(&config, "other", 0, 0, false));
    assert!(!should_cancel(&config, "TEST", 0, 0, false));
    config.worlds[0].enabled = false;
    assert!(!should_cancel(&config, "test", 0, 0, false));
    config.worlds[0].enabled = true;
    config.enabled = false;
    assert!(!should_cancel(&config, "test", 0, 0, false));
    assert_eq!(config.active_worlds(), 0);
}

#[test]
fn extreme_coordinates_do_not_overflow_or_wrap() {
    let config = config_at(i32::MIN, i32::MAX, 1024);
    assert!(should_cancel(&config, "test", i32::MIN, i32::MAX, false));
    assert!(!should_cancel(&config, "test", i32::MAX, i32::MIN, false));
}

#[test]
fn worlds_have_independent_rules() {
    let mut config = config_at(0, 0, 4);
    let mut second = config_at(100, 100, 2).worlds.remove(0);
    second.world = "second".into();
    config.worlds.push(second);
    assert!(should_cancel(&config, "second", 102, 102, false));
    assert!(!should_cancel(&config, "test", 102, 102, false));
    assert!(!should_cancel(&config, "second", 0, 0, false));
    assert_eq!(config.active_worlds(), 2);
}

#[test]
fn default_and_shipped_config_are_disabled() {
    for config in [
        Config::default(),
        Config::parse("").unwrap(),
        Config::parse(EXAMPLE_CONFIG).unwrap(),
    ] {
        assert_eq!(config.active_worlds(), 0);
        assert!(!should_cancel(&config, "horizon-test", 0, 0, false));
    }
}

#[test]
fn invalid_config_is_rejected_without_fallback() {
    let valid =
        "enabled=true\n[[worlds]]\nworld='test'\nenabled=true\ncenter_x=0\ncenter_z=0\nradius=16";
    for invalid in [
        "enabled = 'true'".to_string(),
        "enabled = [".to_string(),
        valid.replace("radius=16", "radius=-1"),
        valid.replace("radius=16", "radius=1025"),
        valid.replace("world='test'", "world=' '"),
        valid.replace("center_x=0", "center_x=2147483648"),
        valid.replace("center_z=0", "centrez=0"),
        format!("{valid}\nunknown=true"),
        format!(
            "{valid}\n[[worlds]]\nworld='test'\nenabled=false\ncenter_x=1\ncenter_z=1\nradius=1"
        ),
    ] {
        assert!(Config::parse(&invalid).is_err(), "accepted: {invalid}");
    }
}

#[test]
fn file_size_utf8_and_read_errors_are_rejected() {
    assert!(Config::parse(&" ".repeat(MAX_CONFIG_BYTES as usize + 1)).is_err());
    assert!(Config::from_reader(&[0xff_u8][..]).is_err());
    struct Broken;
    impl std::io::Read for Broken {
        fn read(&mut self, _buffer: &mut [u8]) -> std::io::Result<usize> {
            Err(std::io::Error::other("fixture read failure"))
        }
    }
    assert!(Config::from_reader(Broken).is_err());
}

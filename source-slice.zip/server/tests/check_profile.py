"""Static checks for the shipped local policy. These do not start a server."""
import hashlib
import json
from pathlib import Path
import tomllib

SERVER = Path(__file__).resolve().parents[1]
config = tomllib.loads((SERVER / "config/pumpkin.toml").read_text(encoding="utf-8"))
plugin = tomllib.loads((SERVER / "config/horizon-base.toml").read_text(encoding="utf-8"))
lock = json.loads((SERVER / "upstream.lock.json").read_text(encoding="utf-8"))
java = config["networking"]["java"]
assert java["address"] == "127.0.0.1:25565"
assert java["online_mode"] and java["encryption"]
for listener in ("bedrock", "query", "management", "lan_broadcast"):
    assert config["networking"][listener]["enabled"] is False, listener
assert config["telemetry"]["enabled"] is False
assert config["telemetry"]["public"] is False
policy = config["plugins"]
assert policy["allow_unsigned"] is False
assert policy["verify_signatures"] is True
assert policy["inherit_env"] is False and policy["loopback_only"] is True
assert policy["max_memory_mb"] == 128
assert policy["allowed_permissions"] == []
assert set(policy["overrides"]) == {"horizon-base"}
override = policy["overrides"]["horizon-base"]
assert override["allow_unsigned"] is True
assert override["max_memory_mb"] == 128
assert set(override["allowed_permissions"]) == {"fs.read.data", "fs.write.data"}
assert plugin["enabled"] is False
assert plugin["worlds"][0]["world"] == config["default_level_name"]
assert plugin["worlds"][0]["radius"] in range(1025)
assert lock["commit"] == "ff873cbbb8cc8fe591fb09aaf7d70b30517a57d0"
assert lock["protocol"] == 777 and lock["wasm_api"] == "0.1.0"
actual_hash = hashlib.sha256((SERVER / "engine/Cargo.lock").read_bytes()).hexdigest()
assert actual_hash == lock["engine_cargo_lock_sha256"]
print("PASS: local listeners, online-mode, telemetry, WASM permissions/memory, defaults, upstream lock")

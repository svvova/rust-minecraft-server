"""Linux loopback integration of pinned Infrarust and patched Pumpkin.

Uses new worlds, synthetic identities, random fixture keys and no auth plugins.
LoginSuccess observed at the proxy is insufficient: the tap must independently
observe the backend's signed query exchange and its own LoginSuccess/rejection.
This does not validate LimboAuth migration, configuration/play or server switches.
"""
import argparse
import asyncio
import datetime as dt
import hashlib
import hmac
import json
import os
from pathlib import Path
import re
import secrets
import shutil
import signal
import socket
import struct
import subprocess
import threading
import time
import uuid

from jam_proxy_forwarding import vint, get_vint, string, get_string, read_packet, send

ROOT = Path(__file__).resolve().parents[2]
NAME = 'JamLinkProbe'
CLAIMED_UUID = uuid.UUID('2a582b6d-73e4-4e7e-b178-645fbc11ae52')
# Java UUID.nameUUIDFromBytes("OfflinePlayer:" + name), not the claimed UUID.
OFFLINE_UUID = uuid.UUID(bytes=hashlib.md5(('OfflinePlayer:' + NAME).encode()).digest(), version=3)
ANSI = re.compile(r'\x1b\[[0-?]*[ -/]*[@-~]')
BACKEND_PORT, TAP_PORT, PROXY_PORT = 25567, 25569, 25568


class FixtureProcess:
    def __init__(self, binary, cwd, logfile, redactions, extra=()):
        self.lines = []
        self.log = logfile.open('w', encoding='utf-8')
        self.process = subprocess.Popen(
            [str(binary), *extra], cwd=cwd, stdin=subprocess.PIPE,
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
            encoding='utf-8', errors='replace',
            env=dict(os.environ, NO_COLOR='1', RUST_LOG='info'))

        def consume():
            for line in self.process.stdout:
                line = ANSI.sub('', line)
                for secret in redactions:
                    line = line.replace(secret, '<fixture-key>')
                self.lines.append(line)
                self.log.write(line)
                self.log.flush()

        self.thread = threading.Thread(target=consume, daemon=True)
        self.thread.start()

    async def stop(self, proxy=False):
        forced = False
        if self.process.poll() is None:
            if proxy:
                self.process.send_signal(signal.SIGTERM)
            else:
                self.process.stdin.write('stop\n')
                self.process.stdin.flush()
                self.process.stdin.close()
            try:
                await asyncio.to_thread(self.process.wait, timeout=30)
            except subprocess.TimeoutExpired:
                forced = True
                self.process.kill()
                await asyncio.to_thread(self.process.wait, timeout=5)
        self.thread.join(timeout=3)
        self.log.close()
        return {'exit_code': self.process.returncode, 'forced': forced,
                'clean': self.process.returncode == 0 and not forced}


def checked_copy(binary, digest, destination):
    actual = hashlib.file_digest(binary.open('rb'), 'sha256').hexdigest()
    if actual != digest:
        raise ValueError('binary digest mismatch')
    shutil.copy2(binary, destination)
    destination.chmod(0o700)


def check_ports():
    for port in (BACKEND_PORT, TAP_PORT, PROXY_PORT):
        with socket.socket() as sock:
            sock.bind(('127.0.0.1', port))


async def ready(process, port):
    deadline = time.monotonic() + 90
    while time.monotonic() < deadline:
        if process.process.poll() is not None:
            raise RuntimeError('fixture process exited before listening')
        try:
            _, writer = await asyncio.open_connection('127.0.0.1', port)
            writer.close()
            await writer.wait_closed()
            return
        except OSError:
            await asyncio.sleep(.2)
    raise TimeoutError('fixture did not listen in time')


class ForwardingTap:
    """Transparent loopback packet relay; only records synthetic login facts."""
    def __init__(self, secret):
        self.secret = secret
        self.connections = []
        self.tasks = set()

    async def handle(self, client_reader, client_writer):
        current = asyncio.current_task()
        self.tasks.add(current)
        record = {'login': False, 'backend_login_success': False,
                  'backend_disconnect': False, 'query_id': None}
        self.connections.append(record)
        backend_writer = None
        directions = []
        try:
            backend_reader, backend_writer = await asyncio.open_connection('127.0.0.1', BACKEND_PORT)

            async def relay(reader, writer, to_backend):
                first = True
                while True:
                    packet_id, payload = await read_packet(reader)
                    if to_backend and first:
                        first = False
                        assert packet_id == 0
                        _, offset = get_vint(payload)
                        _, offset = get_string(payload, offset)
                        next_state, _ = get_vint(payload, offset + 2)
                        record['login'] = next_state == 2
                    if record['login'] and not record['backend_login_success'] and not record['backend_disconnect']:
                        if not to_backend and packet_id == 4:
                            query_id, offset = get_vint(payload)
                            channel, _ = get_string(payload, offset)
                            assert channel == 'velocity:player_info'
                            record['query_id'] = query_id
                        elif to_backend and packet_id == 2 and record['query_id'] is not None:
                            query_id, offset = get_vint(payload)
                            assert payload[offset] == 1
                            signed = payload[offset + 1:]
                            assert len(signed) >= 32
                            record['query_id_matches'] = query_id == record['query_id']
                            record['signature_valid'] = hmac.compare_digest(
                                signed[:32], hmac.digest(self.secret.encode(), signed[32:], 'sha256'))
                            version, pos = get_vint(signed, 32)
                            _, pos = get_string(signed, pos)
                            forwarded_uuid = uuid.UUID(bytes=signed[pos:pos + 16])
                            forwarded_name, _ = get_string(signed, pos + 16)
                            record['forwarding_version'] = version
                            record['forwarded_identity_matches'] = forwarded_uuid == OFFLINE_UUID and forwarded_name == NAME
                        elif not to_backend and packet_id == 2:
                            actual_uuid = uuid.UUID(bytes=payload[:16])
                            actual_name, _ = get_string(payload, 16)
                            record['backend_login_success'] = True
                            record['backend_identity_matches'] = actual_uuid == OFFLINE_UUID and actual_name == NAME
                        elif not to_backend and packet_id == 0:
                            record['backend_disconnect'] = True
                    await send(writer, packet_id, payload)

            directions = [asyncio.create_task(relay(client_reader, backend_writer, True)),
                          asyncio.create_task(relay(backend_reader, client_writer, False))]
            done, pending = await asyncio.wait(directions, return_when=asyncio.FIRST_COMPLETED)
            for task in pending:
                task.cancel()
            results = await asyncio.gather(*directions, return_exceptions=True)
            for result in results:
                if isinstance(result, Exception) and not isinstance(result, (asyncio.IncompleteReadError, ConnectionError)):
                    record['relay_error'] = type(result).__name__
        finally:
            for task in directions:
                if not task.done():
                    task.cancel()
            for writer in (client_writer, backend_writer):
                if writer:
                    writer.close()
                    try:
                        await writer.wait_closed()
                    except ConnectionError:
                        pass
            self.tasks.discard(current)


async def client_login(tap):
    reader, writer = await asyncio.open_connection('127.0.0.1', PROXY_PORT)
    try:
        await send(writer, 0, vint(777) + string('jam-fixture.local') + struct.pack('>H', PROXY_PORT) + vint(2))
        await send(writer, 0, string(NAME) + CLAIMED_UUID.bytes)
        client_success = False
        for _ in range(8):
            packet_id, payload = await read_packet(reader)
            if packet_id == 2:
                actual_uuid = uuid.UUID(bytes=payload[:16])
                actual_name, _ = get_string(payload, 16)
                assert actual_uuid == OFFLINE_UUID and actual_name == NAME
                client_success = True
                await send(writer, 3, b'')  # LoginAcknowledged, protocol 777.
                break
            if packet_id == 0:
                break
            if packet_id == 4:
                query, _ = get_vint(payload)
                await send(writer, 2, vint(query) + b'\x00')
            else:
                raise RuntimeError(f'unexpected login packet {packet_id}')
        deadline = time.monotonic() + 12
        while time.monotonic() < deadline:
            records = [r for r in tap.connections if r['login'] and (r['backend_login_success'] or r['backend_disconnect'])]
            if records:
                return {'client_login_success': client_success, 'backend': records[-1]}
            await asyncio.sleep(.1)
        raise TimeoutError('no backend login decision observed')
    finally:
        writer.close()
        try:
            await writer.wait_closed()
        except ConnectionError:
            pass


async def run(args):
    if os.name != 'posix':
        raise RuntimeError('this integration fixture requires the Linux Actions binaries')
    check_ports()
    run_id = dt.datetime.now(dt.timezone.utc).strftime('%Y%m%d-%H%M%SZ') + '-' + secrets.token_hex(3)
    work = ROOT / 'work/jam-audit/network-probes' / run_id
    out = ROOT / 'outputs/server/jam-network' / run_id
    backend_dir, proxy_dir = work / 'backend', work / 'proxy'
    for directory in (backend_dir, proxy_dir / 'servers', proxy_dir / 'plugins', out):
        directory.mkdir(parents=True, exist_ok=False)
    backend_binary, proxy_binary = backend_dir / 'pumpkin', proxy_dir / 'infrarust'
    checked_copy(args.server, args.server_sha256, backend_binary)
    checked_copy(args.proxy, args.proxy_sha256, proxy_binary)
    secret = secrets.token_hex(32)
    wrong_secret = secrets.token_hex(32)
    (backend_dir / 'pumpkin.toml').write_text(f'''default_level_name = "network-fixture"
seed = "jam-network-fixture"
allow_nether = false
allow_end = false
white_list = false
[networking.java]
enabled = true
address = "127.0.0.1:{BACKEND_PORT}"
online_mode = false
encryption = false
max_players = 2
view_distance = 2
simulation_distance = 2
[networking.java.compression]
enabled = false
[networking.proxy]
enabled = true
[networking.proxy.velocity]
enabled = true
secret = "{secret}"
[networking.bedrock]
enabled = false
[networking.query]
enabled = false
[networking.management]
enabled = false
[networking.lan_broadcast]
enabled = false
[telemetry]
enabled = false
public = false
[plugins]
enabled = false
''', encoding='utf-8')
    (proxy_dir / 'infrarust.toml').write_text(f'''bind = "127.0.0.1:{PROXY_PORT}"
servers_dir = "./servers"
plugins_dir = "./plugins"
compression_threshold = -1
worker_threads = 2
[forwarding]
mode = "velocity"
secret_file = "forwarding.secret"
[auth]
offline_uuid = "offline"
''', encoding='utf-8')
    (proxy_dir / 'servers/jam-fixture.toml').write_text(f'''name = "jam-fixture"
network = "jam-fixture"
domains = ["jam-fixture.local"]
addresses = ["127.0.0.1:{TAP_PORT}"]
proxy_mode = "offline"
forwarding_mode = "velocity"
''', encoding='utf-8')
    report = {'protocol': 777, 'production_data': False,
              'server_sha256': args.server_sha256, 'proxy_sha256': args.proxy_sha256,
              'scope': 'Synthetic offline login to actual Rust backend through actual Rust proxy; no legacy auth, play, switching or production acceptance.',
              'cases': []}
    backend, proxy = None, None
    try:
        backend = FixtureProcess(backend_binary, backend_dir, out / 'server.log', [secret, wrong_secret])
        await ready(backend, BACKEND_PORT)
        for label, proxy_secret in [('same_key', secret), ('different_key', wrong_secret)]:
            (proxy_dir / 'forwarding.secret').write_text(proxy_secret, encoding='utf-8')
            tap = ForwardingTap(secret)
            listener = await asyncio.start_server(tap.handle, '127.0.0.1', TAP_PORT)
            try:
                proxy = FixtureProcess(proxy_binary, proxy_dir, out / f'proxy-{label}.log', [secret, wrong_secret])
                await ready(proxy, PROXY_PORT)
                result = await client_login(tap)
                observed = result['backend']
                passed = observed.get('query_id_matches') and observed.get('forwarded_identity_matches') and not observed.get('relay_error')
                if label == 'same_key':
                    passed = passed and result['client_login_success'] and observed.get('signature_valid') and observed['backend_login_success'] and observed.get('backend_identity_matches')
                else:
                    passed = passed and observed.get('signature_valid') is False and observed['backend_disconnect'] and not observed['backend_login_success']
                result.update(case=label, passed=bool(passed))
                report['cases'].append(result)
                print(json.dumps(result), flush=True)
            finally:
                if proxy:
                    shutdown = await proxy.stop(proxy=True)
                    report.setdefault('proxy_shutdowns', []).append(shutdown)
                    proxy = None
                listener.close()
                await listener.wait_closed()
                for task in list(tap.tasks):
                    task.cancel()
                await asyncio.gather(*list(tap.tasks), return_exceptions=True)
    finally:
        if proxy:
            report.setdefault('proxy_shutdowns', []).append(await proxy.stop(proxy=True))
        if backend:
            report['server_shutdown'] = await backend.stop()
        report['passed'] = (len(report['cases']) == 2 and all(c['passed'] for c in report['cases'])
                            and report.get('server_shutdown', {}).get('clean', False)
                            and len(report.get('proxy_shutdowns', [])) == 2
                            and all(s['clean'] for s in report['proxy_shutdowns']))
        (out / 'report.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
        print(json.dumps({'passed': report['passed'], 'report': str(out / 'report.json')}), flush=True)
    return report['passed']


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--server', required=True, type=Path)
    parser.add_argument('--proxy', required=True, type=Path)
    parser.add_argument('--server-sha256', required=True)
    parser.add_argument('--proxy-sha256', required=True)
    args = parser.parse_args()
    for name in ('server', 'proxy'):
        setattr(args, name, getattr(args, name).resolve())
        digest = getattr(args, name + '_sha256')
        if not re.fullmatch(r'[0-9a-f]{64}', digest):
            parser.error('expected a SHA-256 hex digest')
    raise SystemExit(0 if asyncio.run(run(args)) else 1)
